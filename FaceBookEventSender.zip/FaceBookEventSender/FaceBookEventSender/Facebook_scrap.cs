﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace Azure.Messaging.EventHubs.Processor.Samples
{
    public static class Facebook_scrap
    {
        public static async Task<List<schema>> GenerateBearer()
        {
            string access_token = "EAAL2PZCnIGFgBAFm2EuZBydtoxjnZCZCQWwnHdoTlU1jB1w8jzBoynY00ysyr6dPZAj54Wo8VMCYVyB4dXc6iHZBLXUBMscx467uPCj2EPi8iPpJscZA7nYxRosZBbHPMuDzSeZANpaYZBrS1T42N6wOUUUsoGI4db1lR6OI9ZBZBtsqaoVJ3czpXTLVOLIrLh2hrSqYVyi6ZAv2PZCgZDZD";
            string ClientId = "833704587434072";
            string ClientSecret = "01e2aea176cc5249974f600072a54ba1";
            string grant_type = "fb_exchange_token";
            string pageId = "110558037515329";
            var gettimeline = WebRequest.Create("https://graph.facebook.com/v8.0/oauth/access_token?grant_type=" + grant_type + "&client_id=" + ClientId + "&client_secret=" + ClientSecret + "&&fb_exchange_token=" + access_token) as HttpWebRequest;
            gettimeline.Method = "GET";
            //  gettimeline.Headers[HttpRequestHeader.Authorization] = "Bearer " + access_token;
            string respbody = null;
            var _accessToken = "EAAL2PZCnIGFgBAPY8pFTS7oMZBGE7mWWOkZCFB0xN7W7fpwE0dgEub43Xi8BfXogekw0ycXa6U7vEmBJAjZCARZAyn1YZCyD8oZBtdMC6hhMzToa3qp9BuYH8oYAct79YCpZCb8CvaEn4cbHgZAaP49ZB1z5UWyI5ckUho0cudap2JKgZDZD";
            var _token_type = "bearer";
            var messagefeed = "";
            var url = "";
            if (_accessToken == "" && _token_type == "")
            {
                using (var resp = gettimeline.GetResponse().GetResponseStream())//there request sends
                {
                    var respR = new StreamReader(resp);
                    respbody = respR.ReadToEnd();
                    var _data = (JObject)JsonConvert.DeserializeObject(respbody);
                    _accessToken = _data.Descendants()
                                         .OfType<JProperty>()
                                         .FirstOrDefault(x => x.Name == "access_token")
                                         ?.Value.ToString();
                    _token_type = _data.Descendants()
                                   .OfType<JProperty>()
                                   .FirstOrDefault(x => x.Name == "token_type")
                                   ?.Value.ToString();
                };
            }
            if (_accessToken != "" && _token_type != "")
            {
                var GetFeed = WebRequest.Create("https://graph.facebook.com/v8.0/" + pageId + "/feed?&access_token=" + _accessToken) as HttpWebRequest;
                GetFeed.Method = "GET";
                using (var resp = GetFeed.GetResponse().GetResponseStream())//there request sends
                {
                    var respR = new StreamReader(resp);
                    respbody = respR.ReadToEnd();
                    var _data = (JObject)JsonConvert.DeserializeObject(respbody);
                    messagefeed = _data.Descendants()
                                         .OfType<JProperty>()
                                         .FirstOrDefault(x => x.Name == "message")
                                         ?.Value.ToString();

                    url = _data.Descendants()
                                .OfType<JProperty>()
                                .FirstOrDefault(x => x.Name == "href")
                                ?.Value.ToString();
                };
            }


            List<schema> _lSchema = new List<schema>();
            //var _dd = await GetTwitterArticlesAsync();
            //if (_dd.Content != null && _dd.Content != "")
            //{
            //    _lSchema.Add(_dd);
            //}
            if (messagefeed != null && messagefeed != "")
            {
                schema schema = new schema();
                schema.Content = messagefeed;
                schema.Section = "Facebook";
                schema.URL = (url == null ? "" : url);
                _lSchema.Add(schema);
            }
            return _lSchema;

        }
    }
    public class schema
    {
        public string URL { get; set; }
        public string Content { get; set; }
        public string Section { get; set; }
    }
    public class Hashtagobject
    {
        public string text { get; set; }
        public string url { get; set; }
    }

}
