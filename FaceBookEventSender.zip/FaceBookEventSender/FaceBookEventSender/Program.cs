﻿// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Azure.Messaging.EventHubs.Processor.Samples.Infrastructure;

namespace Azure.Messaging.EventHubs.Processor.Samples
{
    /// <summary>
    ///   The main entry point for executing the samples.
    /// </summary>
    ///
    public static class Program
    {
        /// <summary>
        ///   Serves as the main entry point of the application.
        /// </summary>
        ///
        /// <param name="args">The set of command line arguments passed.</param>
        ///
        public static async Task Main(string[] args)
        {
            // Display the welcome message.

            Console.WriteLine();
            Console.WriteLine("=============================================================================");
            Console.WriteLine("Welcome to the Event Hubs Checkpoint Storage client library for Blob Storage!");
            Console.WriteLine("=============================================================================");
            Console.WriteLine();

            // Prompt for the Event Hubs connection string, if it wasn't passed.
            //Aye!Cobot Config
            var EventHubsConnectionString = "Endpoint=sb://ayecobot.servicebus.windows.net/;SharedAccessKeyName=RootManageSharedAccessKey;SharedAccessKey=5V2GpNMxTTnyprfSg36II5OMGvznjNqKZIbuXCdWVrE=";
            var EventHub = "ayecobotevent";
            var StorageConnectionString = "DefaultEndpointsProtocol=https;AccountName=oneclickstoragedbacc;AccountKey=TfR/+MXdk99Nm7kJ3LuUDsBGGcEFu9KPF6NTjKM3r6n3xcT1iq+B8l87mzWjZ61rzLwxEnCDoddrrSppsam2BA==;EndpointSuffix=core.windows.net";
            var BlobContainer = "ayecobotcon";
            IReadOnlyList<IEventHubsBlobCheckpointSample> samples = LocateSamples();
            await samples[0].RunAsync(EventHubsConnectionString, EventHub, StorageConnectionString, BlobContainer);
            return;
        }

        /// <summary>
        ///   Locates the samples within the solution and creates an instance
        ///   that can be inspected and run.
        /// </summary>
        ///
        /// <returns>The set of samples defined in the solution.</returns>
        ///
        private static IReadOnlyList<IEventHubsBlobCheckpointSample> LocateSamples() =>
            typeof(Program)
              .Assembly
              .ExportedTypes
              .Where(type => (type.IsClass && typeof(IEventHubsBlobCheckpointSample).IsAssignableFrom(type)))
              .Select(type => (IEventHubsBlobCheckpointSample)Activator.CreateInstance(type))
              .ToList();


    }
}