﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Collections.Generic;
using System.Xml;
using XHtmlKit;
using System.Text;
using System.Threading.Tasks;
using System.Linq;

namespace Azure.Messaging.EventHubs.Processor.Samples
{
    public static class Scrappy
    {
        /// <summary>
        /// Sample scraper
        /// </summary>
        public static async Task<List<schema>> GetCodeProjectArticlesAsync(int pageNum = 1)
        {
            List<GetContent> getContents = new List<GetContent>();
            getContents = GetContentDetails();
            List<schema> _lSchema = new List<schema>();
            foreach (GetContent getContent in getContents)
            {
                if (getContent.Company.ToUpper() == "WIPRO")
                {
                    dynamic WiproObj = await GetContentDetailsForWipro(getContent.URL, getContent.Section);
                    _lSchema.AddRange(WiproObj);
                }
                else if (getContent.Company.ToUpper() == "ACCENTURE")
                {
                    dynamic AccentureObj = await GetContentDetailsForAccenture(getContent.URL, getContent.Section);
                    _lSchema.AddRange(AccentureObj);
                }
                else if (getContent.Company.ToUpper() == "DELOITTE")
                {
                    dynamic DeloitteObj = await GetContentDetailsForDeloitte(getContent.URL, getContent.Section);
                    _lSchema.AddRange(DeloitteObj);
                }

            }
            return _lSchema.Take(3).ToList();
        }

        public static List<GetContent> GetContentDetails()
        {
            List<GetContent> _GetContent = new List<GetContent>();
            _GetContent.Add(new GetContent { URL = "https://www.wipro.com/en-IN/newsroom/#PressReleases", Section = "PressRelease Wipro", Company = "Wipro" });
            _GetContent.Add(new GetContent { URL = "https://newsroom.accenture.in/", Section = "Accenture News", Company = "Accenture" });
            _GetContent.Add(new GetContent { URL = "https://www2.deloitte.com/global/en/get-connected/newsroom.html", Section = "Deloitte release", Company = "Deloitte" });
            return _GetContent;
        }

        public static async Task<List<schema>> GetContentDetailsForWipro(string _url, string section)
        {
            List<schema> _lSchema = new List<schema>();
            string url = _url;// "https://www.wipro.com/en-IN/newsroom/#PressReleases";
            XmlDocument page = await XHtmlLoader.LoadWebPageAsync(url);
            dynamic articles = page.SelectNodes("//div[@class='dropdown-button-content-news']");
            foreach (XmlNode childNode in articles)
            {
                var childNodes = childNode.SelectNodes("./*");
                if (childNodes != null)
                {
                    int i = 0;
                    schema _obj = new schema();
                    var _dated = DateTime.Today.AddDays(-1);
                    DateTime today = DateTime.Today;
                    foreach (XmlNode cchildNode in childNode.ChildNodes)
                    {
                        if (i == 0)
                        {
                            _obj.Content = cchildNode.InnerText;
                        }
                        if (i == 1)
                        {
                            _dated = Convert.ToDateTime(cchildNode.InnerText.Substring(0, 12));
                        }
                        if (i == 2)
                        {
                            if (cchildNode.Attributes.Count > 1)
                            {
                                _obj.URL = cchildNode.Attributes[1].Value;
                            }

                        }

                        i += 1;
                    }
                    if (Convert.ToDateTime(_dated) >= today)
                    {
                        _obj.Section = section;//"Notification from Wipro";
                        _lSchema.Add(_obj);
                    }
                }
            }
            return _lSchema;
        }

        public static async Task<List<schema>> GetContentDetailsForAccenture(string _url, string section)
        {
            List<schema> _lSchema = new List<schema>();
            string url = _url; //"https://newsroom.accenture.in/";
            XmlDocument page = await XHtmlLoader.LoadWebPageAsync(url);
            dynamic articles = page.SelectNodes("//div[@id='tek-wrap-centerwell']//div[contains(@class,'section article-list')]");
            foreach (XmlNode childNode in articles)
            {
                var childNodes = childNode.SelectNodes("./*");
                if (childNodes != null)
                {
                    schema _obj = new schema();
                    var _dated = DateTime.Today;
                    DateTime today = DateTime.Today.AddDays(-2);
                    foreach (XmlNode cchildNode in childNode.ChildNodes)
                    {
                        _obj.Content = cchildNode.ChildNodes[0].InnerText.Replace("\t", string.Empty).Replace("\n", string.Empty).Replace("\r", string.Empty) + " " + cchildNode.ChildNodes[1].InnerText.Replace("\t", string.Empty).Replace("\n", string.Empty).Replace("\r", string.Empty);
                        _obj.URL = cchildNode.ChildNodes[2].SelectNodes("./*")[0].SelectNodes("./*")[0].Attributes[0].Value;
                        _dated = Convert.ToDateTime(cchildNode.ChildNodes[2].SelectNodes("./*")[1].InnerText);
                    }
                    if (Convert.ToDateTime(_dated) >= today)
                    {
                        _obj.Section = section; //"Accenture News";
                        _lSchema.Add(_obj);
                    }
                }
            }
            return _lSchema.Take(3).ToList();
        }

        public static async Task<List<schema>> GetContentDetailsForDeloitte(string _url, string section)
        {
            List<schema> _lSchema = new List<schema>();
            string url = _url;// "https://www2.deloitte.com/global/en/get-connected/newsroom.html";
            XmlDocument page = await XHtmlLoader.LoadWebPageAsync(url);
            dynamic articles = page.SelectNodes("//div[contains(@class,'featuredpromo')]");
            foreach (XmlNode childNode in articles)
            {
                schema _obj = new schema();
                _obj.URL = childNode.ChildNodes[0].Attributes[1].Value;
                _obj.Content = (childNode.ChildNodes[0].Attributes[4].Value.ToString().Split(" ").Length > 2 ? childNode.ChildNodes[0].Attributes[4].Value : childNode.ChildNodes[0].Attributes[5].Value);
                _obj.Section = section; // "Deloitte release";
                _lSchema.Add(_obj);
            }
            return _lSchema.Take(3).ToList();
        }

    }
    public class schema
    {
        public string URL { get; set; }
        public string Content { get; set; }
        public string Section { get; set; }
    }
    public class GetContent
    {
        public string URL { get; set; }
        public string Section { get; set; }
        public string Company { get; set; }
    }

}
