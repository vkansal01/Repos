﻿// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

namespace VirtualAssistantexample.Models
{
    public class UserProfileState
    {
        public string Name { get; set; }
    }
}
