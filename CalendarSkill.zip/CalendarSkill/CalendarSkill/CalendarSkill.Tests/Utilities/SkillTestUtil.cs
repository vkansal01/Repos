﻿// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

using System.Collections.Generic;
using Luis;
using Microsoft.Bot.Builder;
using CalendarSkill.Tests.Mocks;
using CalendarSkill.Tests.Utterances;

namespace CalendarSkill.Tests.Utilities
{
    public class SkillTestUtil
    {
        private static Dictionary<string, IRecognizerConvert> _utterances = new Dictionary<string, IRecognizerConvert>
        {
            { SampleDialogUtterances.Trigger, CreateIntent(SampleDialogUtterances.Trigger, CalendarSkillLuis.Intent.Sample) },
        };

        public static MockLuisRecognizer CreateRecognizer()
        {
            var recognizer = new MockLuisRecognizer(defaultIntent: CreateIntent(string.Empty, CalendarSkillLuis.Intent.None));
            recognizer.RegisterUtterances(_utterances);
            return recognizer;
        }

        public static CalendarSkillLuis CreateIntent(string userInput, CalendarSkillLuis.Intent intent)
        {
            var result = new CalendarSkillLuis
            {
                Text = userInput,
                Intents = new Dictionary<CalendarSkillLuis.Intent, IntentScore>()
            };

            result.Intents.Add(intent, new IntentScore() { Score = 0.9 });

            result.Entities = new CalendarSkillLuis._Entities
            {
                _instance = new CalendarSkillLuis._Entities._Instance()
            };

            return result;
        }
    }
}
