﻿using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AyeCobotSenderWebJob
{
    class Program
    {
        static void Main(string[] args)
        {
            //var client = new RestClient("https://scrapybot.azurewebsites.net/api/notify");
            var client = new RestClient("https://hsbcvirtualassistant.azurewebsites.net/api/notify");
            var request = new RestRequest(Method.GET);
            request.AddHeader("cache-control", "no-cache");
            client.Execute(request);

        }
    }
}
